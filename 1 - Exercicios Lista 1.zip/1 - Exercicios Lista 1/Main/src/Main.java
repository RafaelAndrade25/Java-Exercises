//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Carro obj1 = new Carro ("Fiat","Palio", "branco", 2018, false,120 );

        Carro obj2 = new Carro("GM", "Onix", "cinza", 2020, false,240 );

//        obj1.mostraCarro();
//        obj2.mostraCarro();
        obj1.delisgar();
        obj1.ligar();
        obj1.acelerar(10);
        obj1.frear(5);
        obj1.mostraCarro();
    }
}