public class Carro {
    //Variaveis
    public String marca, modelo, cor;
    public int ano;
    public boolean motor; //True or False
    public float velAtual;

    //Construtor para instanciar objeto
    public Carro(String marca, String modelo, String cor, int ano, boolean motor, float velAtual){
        this.marca = marca;
        this.modelo = modelo;
        this.cor = cor;
        this.ano = ano;
        this.motor = motor;
        this.velAtual = velAtual;
    }
    public void mostraCarro(){
        System.out.println("\n Marca:" +  this.marca + " Modelo:" + this.modelo + " Cor:" + this.cor + " Motor:" + this.motor + " vel:" + velAtual);
    }
    //Ligar o carro
    public void ligar(){
        if(!this.motor){
            this.motor = true;
        }

    }
    public void delisgar() {
        if (this.motor) {
            this.motor = false;
        }
    }
    public void acelerar(float x) {
        if (this.motor) {
            this.velAtual += x;
        }
    }
    public void frear(float x){
        if(this.motor){
            if(this.velAtual - x >= 0){
                this.velAtual -= x;

            }

        }
    }

}
